<div class="slide active" id="sld-welcome">
   <div id="transparency"></div>
   <a id="touch-start" onclick="go('#sld-welcome','#sld-visitor-type')">
      <h1>Welcome To</h1>
      <i class="fa fa-chevron-left" id="left-arrow"></i>
      <i class="fa fa-chevron-right" id="right-arrow"></i>
      <img id="brand" src="<?php bloginfo('template_url'); ?>/img/romeonavneg.svg">
      <span>Tap To Check In</span>
   </a>
</div>

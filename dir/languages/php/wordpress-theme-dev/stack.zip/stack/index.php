

<?php get_header(); ?>

<?php include 'stack/01__welcome.php' ?>

<?php include 'stack/02__visitor-type.php' ?>

<?php include 'stack/03__visitor-info.php' ?>

<?php include 'stack/04__nda.php' ?>

<?php get_footer(); ?>

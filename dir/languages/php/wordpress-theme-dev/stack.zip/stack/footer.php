
    <?php wp_footer(); ?>
    <script src="<?php bloginfo('template_url'); ?>/js/jquery-3.3.1.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
    <script src="<?php bloginfo('template_url'); ?>/js/main.js"></script>

  </body>
</html>
